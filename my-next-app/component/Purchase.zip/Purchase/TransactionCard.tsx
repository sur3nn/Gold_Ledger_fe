"use client";

import { useMemo, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";

interface Factory {
  id: number;
  name: string;
}

interface TransactionCardProps {
  factories: Factory[];
  selectedFactory: Factory | null;
  setSelectedFactory: React.Dispatch<React.SetStateAction<Factory | null>>;
  factoryName: string;
  setFactoryName: React.Dispatch<React.SetStateAction<string>>;
  paymentMethod: string;
  setPaymentMethod: React.Dispatch<React.SetStateAction<string>>;
  solidGoldGiven: number;
  setSolidGoldGiven: React.Dispatch<React.SetStateAction<number>>;
}

const SelectField = ({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: { label: string; value: string }[];
}) => (
  <div className="flex flex-col gap-2">
    <label className="text-[13px] font-semibold text-gray-700">{label}</label>
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-12 border border-gray-200 rounded-2xl px-4 pr-10 text-[14px] text-gray-700 bg-white appearance-none outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 transition-all cursor-pointer"
      >
        {options.map((item) => (
          <option key={item.value} value={item.value}>
            {item.label}
          </option>
        ))}
      </select>
      <ChevronDown
        size={16}
        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"
      />
    </div>
  </div>
);

const TransactionCard = ({
  factories,
  selectedFactory,
  setSelectedFactory,
  factoryName,
  setFactoryName,
  paymentMethod,
  setPaymentMethod,
  solidGoldGiven,
  setSolidGoldGiven,
}: TransactionCardProps) => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredFactories = useMemo(() => {
    if (!search.trim()) return factories;
    return factories.filter((x) =>
      x.name.toLowerCase().includes(search.toLowerCase())
    );
  }, [factories, search]);

  return (
    <>
      <div className="bg-white rounded-3xl overflow-hidden flex-1">
        {/* Header */}
        <div
          className="px-5 sm:px-6 py-4"
          style={{ background: "linear-gradient(90deg, #fff5f2, #f5f2ff)" }}
        >
          <h3 className="text-[15px] font-bold text-gray-800">
            Transaction Details
          </h3>
        </div>

        <div className="p-4 sm:p-6 flex flex-col gap-5">
          {/* Factory + Payment — stack on mobile, 2-col on sm+ */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Factory Search */}
            <div className="flex flex-col gap-2 relative">
              <label className="text-[13px] font-semibold text-gray-700">
                Factory Source
              </label>
              <input
                ref={inputRef}
                type="text"
                value={selectedFactory ? selectedFactory.name : search}
                placeholder="Search Factory"
                onFocus={() => setOpen(true)}
                onChange={(e) => {
                  const value = e.target.value;
                  setSelectedFactory(null);
                  setFactoryName(value);
                  setSearch(value);
                  setOpen(true);
                }}
                className="w-full h-12 border border-gray-200 rounded-2xl px-4 text-[14px] text-gray-700 outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
              />
              {open && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-2xl shadow-xl z-50 max-h-60 overflow-auto">
                  {filteredFactories.map((factory) => (
                    <button
                      key={factory.id}
                      type="button"
                      onClick={() => {
                        setSelectedFactory(factory);
                        setFactoryName("");
                        setSearch(factory.name);
                        setOpen(false);
                      }}
                      className="w-full px-4 py-3 text-left hover:bg-gray-50 text-sm"
                    >
                      {factory.name}
                    </button>
                  ))}
                  {search.trim() && filteredFactories.length === 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFactory(null);
                        setFactoryName(search);
                        setOpen(false);
                      }}
                      className="w-full px-4 py-3 text-left text-indigo-600 font-semibold hover:bg-indigo-50"
                    >
                      + Create "{search}"
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Payment Method */}
            <SelectField
              label="Payment Method"
              value={paymentMethod}
              onChange={setPaymentMethod}
              options={[
                { label: "Metal Credit", value: "1" },
                { label: "Cash", value: "2" },
                { label: "Bank Transfer", value: "3" },
                { label: "UPI", value: "4" },
              ]}
            />
          </div>

          {/* Solid Gold Given */}
          <div className="flex flex-col gap-2">
            <label className="text-[13px] font-semibold text-gray-700">
              Solid Gold Given (g)
            </label>
            <div className="relative">
              <input
                type="number"
                value={solidGoldGiven || ""}
                onChange={(e) =>
                  setSolidGoldGiven(
                    e.target.value === "" ? 0 : Number(e.target.value)
                  )
                }
                placeholder="0"
                className="w-full h-12 border border-gray-200 rounded-2xl pl-4 pr-14 text-[14px] text-gray-700 bg-white outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 transition-all appearance-none"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setSolidGoldGiven(
                      Number((solidGoldGiven + 0.001).toFixed(3))
                    )
                  }
                  className="w-2 h-2 flex items-center justify-center text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all"
                >
                  ▲
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setSolidGoldGiven(
                      Math.max(
                        0,
                        Number((solidGoldGiven - 0.001).toFixed(3))
                      )
                    )
                  }
                  className="w-2 h-2 flex items-center justify-center text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all"
                >
                  ▼
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TransactionCard;
